#!/bin/bash

#consul template root dir
root_dir=/root/tsf-consul-template-docker

pid=`ps -ef |grep "./consul-template" | grep -v 'grep' | awk '{print $2}'`

if [ $pid ];then
  kill -9 $pid
fi

#execute start
cd $root_dir/bin
/bin/bash -c "./consul-template -log-level=debug -config=$root_dir/config/scheduler/scheduler.hcl >& $root_dir/log/scheduler.log &"
