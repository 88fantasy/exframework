#!/bin/bash

#consul template root dir
root_dir=/root/tsf-consul-template-docker

#monitor log file
monitor_log=$root_dir/log/monitor.log

Monitor()
{
  #current timestamp
  current_timestamp=$(date '+%Y/%m/%d %H:%M:%S')

  #pid=$(ps -ef |grep consul-template | grep consul-addr | grep -v 'grep' | awk '{print $2}')
  count=$(ps -ef |grep "./consul-template" | grep -v 'grep' | wc -l)

  if [ $count -gt 0 ];then
    echo "$current_timestamp [info] consul template running..."
  else
    echo "$current_timestamp [error] consul template exited, restarting..."
    sh $root_dir/script/restart.sh >/dev/null 2>&1
    if [ $? -eq 0 ];then
      echo "$current_timestamp [info] consul template restarted."
    else
      echo "$current_timestamp [error] consul template restart failed."
    fi 
  fi
}

while true
do
  sleep 10s
  Monitor>>$monitor_log
done
