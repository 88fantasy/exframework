#!/bin/bash

#consul template root dir
root_dir=/root/tsf-consul-template-docker

pid=`ps -ef |grep "./consul-template" | grep -v 'grep' | awk '{print $2}'`

if [ $pid ];then
  kill -9 $pid

  #sed -i '/tsf-consul-template/d' /var/spool/cron/root
  #sed -i '/^$/d' /var/spool/cron/root
  exist=$(ps -ef | grep "$root_dir/script/monitor.sh" | grep -v 'grep' | wc -l)
  if [ $exist -gt 0 ];
  then
    echo "del monitor for consul template"

    mid=`ps -ef |grep "$root_dir/script/monitor.sh" | grep -v 'grep' | awk '{print $2}'`
    kill -9 $mid
  fi

  cd $root_dir/config/worker && rm -f worker.hcl
  cd $root_dir/config/scheduler && rm -f scheduler.hcl
  cd $root_dir/config/scheduler && rm -f worker.hcl.ctmpl

  echo "consul template stopped"
fi
