#!/bin/bash

#consul template root dir
root_dir=/root/tsf-consul-template-docker

#default consul addr
consul_ip=169.254.0.77
consul_port=8000

#default consul token
consul_token=tsf-token-default

#default application and group id
tsf_applicat_id=tsf-application-default
tsf_appgroup_id=tsf-appgroup-default

#check running process
count=$(ps -ef |grep "./consul-template" | grep -v 'grep' | wc -l)
if [ $count -gt 0 ];then
  echo "consul template running..."
  exit
fi

#env variables
if [ $tsf_consul_ip ];
then  
  consul_ip=${tsf_consul_ip}
fi

if [ $tsf_consul_port ];
then                  
  consul_port=${tsf_consul_port}
fi

if [ $tsf_token ];
then                  
  consul_token=${tsf_token}
fi

if [ $tsf_application_id ];
then
  tsf_applicat_id=${tsf_application_id}
fi

if [ $tsf_group_id ];
then
  tsf_appgroup_id=${tsf_group_id}
fi

#sed config file
cp $root_dir/config/scheduler/scheduler.hcl.example $root_dir/config/scheduler/scheduler.hcl
cp $root_dir/config/scheduler/worker.hcl.ctmpl.example $root_dir/config/scheduler/worker.hcl.ctmpl
sed -i "s/TSF_CONSUL_IP/${consul_ip}/" $root_dir/config/scheduler/scheduler.hcl
sed -i "s/TSF_CONSUL_PORT/$consul_port/" $root_dir/config/scheduler/scheduler.hcl
sed -i "s/TSF_CONSUL_TOKEN/$consul_token/" $root_dir/config/scheduler/scheduler.hcl
sed -i "s/TSF_APPLICATION_ID/$tsf_applicat_id/" $root_dir/config/scheduler/worker.hcl.ctmpl
sed -i "s/TSF_APPGROUP_ID/$tsf_appgroup_id/" $root_dir/config/scheduler/worker.hcl.ctmpl

#execute start
cd $root_dir/bin
/bin/bash -c "./consul-template -log-level=debug -config=$root_dir/config/scheduler/scheduler.hcl >& $root_dir/log/scheduler.log &"

#add monitor task
exist=$(ps -ef | grep "$root_dir/script/monitor.sh" | grep -v 'grep' | wc -l)
if [ $exist -eq 0 ];
then
    echo "add monitor for consul template"

    sh $root_dir/script/monitor.sh &
fi

echo "consul template started"
